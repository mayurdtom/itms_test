"""faulty_tracker
"""

__version__ = "0.1"
