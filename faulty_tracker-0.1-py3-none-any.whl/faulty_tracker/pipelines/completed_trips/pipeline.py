"""
This is a boilerplate pipeline 'completed_trips'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import get_completed_trips_table, typecast_completed_trips


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=get_completed_trips_table,
                inputs=None,
                outputs="completed_trips_df",
                name="get_completed_trips_table_node",
            ),
            node(
                func=typecast_completed_trips,
                inputs="completed_trips_df",
                outputs="typecasted_completed_trips_df",
                name="typecast_completed_trips_node",
            )
        ]
    )
