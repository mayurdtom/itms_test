"""
This is a boilerplate pipeline 'completed_trips'
generated using Kedro 0.18.12
"""
from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

def get_connection_engine():
	DATABASE_USER = "postgres"
	DATABASE_PASSWORD = "timescaledbpg"
	DATABASE_HOST = "65.2.69.78"
	DATABASE_PORT = "32588"
	DATABASE_NAME = "postgresdb"

	connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
	engine = create_engine(connection_string)
	return engine


def create_sql_query() -> str:
	UTC = pytz.utc
	now = datetime.now(UTC)
	start_time = now.strftime("'%Y-%m-%d 00:00:00'")
	start_time = int(datetime.strptime(start_time, "'%Y-%m-%d 00:00:00'").timestamp())*1000000
	completed_trips_sql_query = f"SELECT * FROM trip_status WHERE observe_time >= '{start_time}'  AND status = 'COMPLETED'"
	return completed_trips_sql_query


def get_completed_trips_table() -> dd:
	
	completed_trips_pandas_df = pd.read_sql(create_sql_query(), con=get_connection_engine())
	completed_trips_df = dd.from_pandas(completed_trips_pandas_df, npartitions=1)
	return completed_trips_df[["trip_id"]]

def typecast_completed_trips(completed_trips_df: dd) -> dd:
	completed_trips_df["trip_id"] = completed_trips_df["trip_id"].astype(int)
	completed_trips_df = completed_trips_df.repartition(npartitions=1)
	return completed_trips_df






