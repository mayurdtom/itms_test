"""
This is a boilerplate pipeline 'eta'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import get_eta_table, convert_to_unix, eta_typecast


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=get_eta_table,
                inputs=None,
                outputs="eta",
                name="get_eta_table_node",
            ),
            node(
                func=convert_to_unix,
                inputs="eta",
                outputs="eta_converted",
                name="convert_to_unix_node",
            ),
            node(
                func=eta_typecast,
                inputs="eta_converted",
                outputs="typecasted_eta_df",
                name="eta_typecast_node",
            )

        ]
    )
