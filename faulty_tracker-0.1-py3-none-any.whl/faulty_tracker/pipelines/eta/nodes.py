"""
This is a boilerplate pipeline 'eta'
generated using Kedro 0.18.12
"""

from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import dask
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")


def get_connection_engine():
	DATABASE_USER = "postgres"
	DATABASE_PASSWORD = "timescaledbpg"
	DATABASE_HOST = "65.2.69.78"
	DATABASE_PORT = "32588"
	DATABASE_NAME = "postgresdb"

	connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
	engine = create_engine(connection_string)
	return engine

def create_sql_query() -> str:
	UTC = pytz.utc
	now_time = datetime.now(UTC)
	start_time = now_time.strftime("'%Y-%m-%d 00:00:00+00:00'")
	end_time = now_time.strftime("'%Y-%m-%d %H:%M:%S+00:00'")
	return f"SELECT * FROM itms WHERE observationdatetime >= {start_time} AND observationdatetime <= {end_time} ORDER BY observationdatetime"


def get_eta_table() -> dd:
	eta_pandas = pd.read_sql(create_sql_query(), con=get_connection_engine())
	eta = dd.from_pandas(eta_pandas, npartitions=20)
	return eta

def convert_to_unix(eta: dd) -> dd:
	eta['actual_trip_start_time'] = eta['actual_trip_start_time'].map(lambda x: int(datetime.strptime(str(x), "%Y-%m-%d %H:%M:%S+00:00").timestamp()*1000000),meta=('actual_trip_start_time', 'i8'))
	eta['last_stop_arrival_time'] = eta['last_stop_arrival_time'].map(lambda x: None if pd.isna(x) else int(datetime.strptime(str(x), "%Y-%m-%d %H:%M:%S+00:00").timestamp()*1000000))
	eta['observationdatetime'] = eta['observationdatetime'].map(lambda x: int(datetime.strptime(str(x), "%Y-%m-%d %H:%M:%S+00:00").timestamp()*1000000),meta=('observationdatetime', 'i8'))
	return eta

def eta_typecast(eta: dd) -> dd:
	eta['trip_id']=eta['trip_id'].astype('int')
	eta['last_stop_id']=eta['last_stop_id'].astype('int')
	eta['trip_delay']=eta['trip_delay'].astype('float')
	eta = eta.repartition(npartitions=1)
	return eta
