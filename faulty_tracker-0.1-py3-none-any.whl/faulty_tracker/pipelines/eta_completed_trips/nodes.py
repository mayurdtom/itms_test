"""
This is a boilerplate pipeline 'eta_completed_trips'
generated using Kedro 0.18.12
"""
from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")



def get_connection_engine():
	DATABASE_USER = "postgres"
	DATABASE_PASSWORD = "timescaledbpg"
	DATABASE_HOST = "65.2.69.78"
	DATABASE_PORT = "32588"
	DATABASE_NAME = "postgresdb"

	connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
	engine = create_engine(connection_string)
	return engine


def create_eta_trip_route_table(typecasted_completed_trips_df, typecasted_eta_df) -> dd:
	eta_completed_df = typecasted_completed_trips_df.merge(typecasted_eta_df, on="trip_id", how="inner")
	eta_completed_df = eta_completed_df[["id","trip_id","observationdatetime", "vehicle_label", "route_id","license_plate"]]

	eta_trip_route = eta_completed_df.sort_values("observationdatetime")
	return eta_trip_route[["id","observationdatetime","trip_id", "route_id","license_plate","vehicle_label"]]
	

def compute_time_to_message(group):
	group = group.sort_values('observationdatetime')
	group['time_to_message'] = group['observationdatetime'] - group['observationdatetime'].shift(1)
	return group

def add_time_to_message_col(eta_trip_route: dd) -> dd:
	if len(eta_trip_route) == 0:
		return eta_trip_route
	eta_trip_route = eta_trip_route.groupby(["trip_id", "vehicle_label"]).apply(compute_time_to_message)
	return eta_trip_route

def faultDetection(time_to_message):
	if time_to_message is None:
		return 1
	if time_to_message>110:
		return 1
	else:
		return 0

def add_count_cols(group):
    group['faulty_count']= (group['fault'] == 1).sum()
    group['not_faulty_count']= (group['fault'] == 0).sum()
    return group

def add_fault_cols(eta_trip_route: dd) -> dd:
	if len(eta_trip_route) == 0:
		return eta_trip_route

	eta_trip_route['fault']=eta_trip_route['time_to_message'].map(lambda time_to_message: faultDetection(time_to_message))
	eta_trip_route = eta_trip_route.reset_index(drop=True)

	eta_trip_route = eta_trip_route.groupby(['trip_id', 'license_plate']).apply(add_count_cols).reset_index(drop=True)
	eta_trip_route['is_faulty'] = ((eta_trip_route['not_faulty_count'] < eta_trip_route['faulty_count']).astype(bool))
	eta_trip_route['not_faulty_count'] = eta_trip_route['not_faulty_count'].astype('int')
	eta_trip_route['faulty_count'] = eta_trip_route['faulty_count'].astype('int')

	return eta_trip_route


def add_new_cols(eta_trip_route: dd) -> dd:
	if len(eta_trip_route) == 0:
		return eta_trip_route

	eta_trip_route['primary_key'] = eta_trip_route['trip_id'].astype(str) + eta_trip_route.apply(lambda row: str(pd.to_datetime('today').date()), axis=1)
	
	EPOCHS_IN_5_HR_30_MINS = 5 * 60 * 60 + 30 * 60
	now_time = time.time()

	observe_time = int((now_time + EPOCHS_IN_5_HR_30_MINS) * 1000000)
	eta_trip_route["observe_time"] = observe_time

	eta_trip_route.compute().to_sql("faulty_tracker", get_connection_engine().connect(), if_exists="append")
	return eta_trip_route

	
