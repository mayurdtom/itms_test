"""
This is a boilerplate pipeline 'eta_completed_trips'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import create_eta_trip_route_table, add_time_to_message_col, add_fault_cols, add_new_cols


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=create_eta_trip_route_table,
                inputs=["typecasted_completed_trips_df", "typecasted_eta_df"],
                outputs="eta_trip_route_df",
                name="create_eta_trip_route_table_node",
            ),
            node(
                func=add_time_to_message_col,
                inputs="eta_trip_route_df",
                outputs="eta_trip_route_with_time_df",
                name="add_time_to_message_col_node",
            ),
            node(
                func=add_fault_cols,
                inputs="eta_trip_route_with_time_df",
                outputs="eta_trip_route_with_fault_df",
                name="add_fault_cols_node",
            ),
            node(
                func=add_new_cols,
                inputs="eta_trip_route_with_fault_df",
                outputs="final_eta_trip_route_df",
                name="add_new_cols_node",
            )

        ]
    )
