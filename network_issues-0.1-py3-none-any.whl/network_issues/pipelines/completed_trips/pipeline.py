"""
This is a boilerplate pipeline 'completed_trips'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import get_completed_trip_ids


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=get_completed_trip_ids,
                inputs=None,
                outputs="completed_trip_ids",
                name="get_completed_trip_ids_node",
            )
        ]
    )