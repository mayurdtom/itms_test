from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime, timedelta
import h3
import math
import uuid


def _connect_to_postgres():
    DATABASE_USER = "postgres"
    DATABASE_PASSWORD = "timescaledbpg"
    DATABASE_HOST = "65.2.69.78"
    DATABASE_PORT = "32588"
    DATABASE_NAME = "postgresdb"

    connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
    return create_engine(connection_string)


def _get_start_and_end_time() -> (int, int):
    EPOCHS_IN_A_WEEK = 7 * 24 * 60 * 60 * 1000000
    now_time = int(time.time() * 1000000)
    start_time = now_time - EPOCHS_IN_A_WEEK
    end_time = now_time

    return start_time, end_time


def get_completed_trip_ids() -> dd:
    start_time, end_time = _get_start_and_end_time()
    completed_trips_sql_query = f"SELECT * FROM trip_status WHERE observe_time >= '{start_time}' AND observe_time <= '{end_time}' AND status = 'COMPLETED'"
    completed_trips_pandas_df = pd.read_sql(completed_trips_sql_query, con=_connect_to_postgres())
    completed_trips_df = dd.from_pandas(completed_trips_pandas_df, npartitions=1)

    completed_trips = completed_trips_df[["trip_id"]]
    completed_trips["trip_id"] = completed_trips["trip_id"].astype(int)
    
    return completed_trips