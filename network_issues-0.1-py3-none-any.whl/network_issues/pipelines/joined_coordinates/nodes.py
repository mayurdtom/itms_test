#!/usr/bin/env python
# coding: utf-8

from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime, timedelta
import h3
import math
import uuid


def _connect_to_postgres():
    DATABASE_USER = "postgres"
    DATABASE_PASSWORD = "timescaledbpg"
    DATABASE_HOST = "65.2.69.78"
    DATABASE_PORT = "32588"
    DATABASE_NAME = "postgresdb"

    connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
    return create_engine(connection_string)


def _get_eta_trip_route_data(completed_trip_ids: dd, eta: dd) -> dd:
    eta_completed_df = completed_trip_ids.merge(eta, on="trip_id", how="inner").compute()
    print("Merged completed trip ids and eta.")
    eta_completed_df = eta_completed_df[["trip_id", "observationdatetime", "last_stop_id", "route_id", "location.coordinates", "license_plate"]]
    
    eta_trip_route = eta_completed_df.sort_values("observationdatetime")
    eta_trip_route = eta_trip_route[["trip_id", "observationdatetime", "route_id", "last_stop_id", "location.coordinates"]]

    return eta_trip_route



# In the ITMS table the column "location.coordinates" contains values of the form `(<longitude>,<latitude>)`
def _extract_lat_lon_itms(coords: str) -> (float, float):
    lon, lat = str(coords)[1:-1].split(",")
    return float(lat), float(lon)

def _geoToH3(coords: [float, float]):
    latitude, longitude = coords
    resolution = 8
    return h3.geo_to_h3(latitude, longitude, resolution)

def _h3ToCoordinates(h3_hash):
    return  '{"type": "Polygon", "geometry": {"type": "Polygon", "coordinates": ['+ str(h3.h3_set_to_multi_polygon([h3_hash], geo_json=True)[0][0]) +'] }}'

def _h3ToGeo(h3_hash):
    return str(h3.h3_set_to_multi_polygon([h3_hash], geo_json=True)[0][0])


def left_anti_join_bus_route_and_eta_trip_route(bus_routes_bins: dd, completed_trip_ids: dd, eta: dd) -> dd:
    eta_trip_route_bins = _get_eta_trip_route_data(completed_trip_ids, eta)
    eta_trip_route_bins = eta_trip_route_bins.reset_index()

    eta_trip_route_bins["h3"] = eta_trip_route_bins["location.coordinates"].map(lambda coords: _geoToH3(_extract_lat_lon_itms(coords)))

    bus_routes_bins = bus_routes_bins.compute()
    joined_coordinates = bus_routes_bins[~bus_routes_bins["h3"].isin(eta_trip_route_bins["h3"])]
    
    return joined_coordinates


def _replace_regex(dataframe: dd) -> dd:
    dataframe["polygon"] = dataframe["polygon"].replace(r"\(", "[", regex=True)
    dataframe["polygon"] = dataframe["polygon"].replace(r"\)", "]", regex=True)

    dataframe["coordinates"] = dataframe["coordinates"].replace(r"\)", "]", regex=True)
    dataframe["coordinates"] = dataframe["coordinates"].replace(r"\(", "[", regex=True)
    
    return dataframe


def prepare_final_table(joined_coordinates: pd.DataFrame) -> dd:
    joined_coordinates["polygon"] = joined_coordinates["h3"].map(lambda h3: _h3ToGeo(h3))
    joined_coordinates["coordinates"] = joined_coordinates["h3"].map(lambda h3: _h3ToCoordinates(h3))
    
    joined_coordinates_grouped = joined_coordinates.groupby("h3")
    weight = joined_coordinates_grouped["route_id"].transform("count")
    joined_coordinates["weight"] = weight
    maximum = joined_coordinates["weight"].max()
    minimum = joined_coordinates["weight"].min()
    
    joined_coordinates = joined_coordinates.assign(normalize=joined_coordinates["weight"].apply(lambda weight: math.floor(((5-1)*(weight - minimum) / (maximum - minimum))+1)))
    joined_coordinates["normalize"] = joined_coordinates["normalize"].astype(int)
    
    joined_coordinates["sorting_key"] = "A"
    window = joined_coordinates.groupby(joined_coordinates["sorting_key"]).cumcount()
    joined_coordinates["primary_key"] = (joined_coordinates["h3"] + joined_coordinates.apply(lambda row: str(uuid.uuid4()), axis=1) +
                     window.astype(str) +
                     joined_coordinates.apply(lambda row: str(pd.to_datetime('today').date()), axis=1) +
                     window.astype(str))
    joined_coordinates = joined_coordinates.loc[:, ["h3", "route_id", "bus_route_latitude", "bus_route_longitude", "normalize", "primary_key", "polygon", "coordinates"]]
    
    new_column_names = {"bus_route_latitude": "latitude", "bus_route_longitude": "longitude", "normalize": "weight"}
    joined_coordinates = joined_coordinates.rename(columns=new_column_names)
    
    observe_time = int(time.time() * 1000000)
    joined_coordinates["observe_time"] = observe_time

    joined_coordinates = _replace_regex(joined_coordinates)
    joined_coordinates.to_sql("network_issues", con=_connect_to_postgres().connect(), if_exists="append")

    return dd.from_pandas(joined_coordinates, npartitions=1)
