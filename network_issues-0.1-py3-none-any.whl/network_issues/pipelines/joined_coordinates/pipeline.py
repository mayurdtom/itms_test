from kedro.pipeline import Pipeline, node, pipeline

from .nodes import left_anti_join_bus_route_and_eta_trip_route, prepare_final_table


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=left_anti_join_bus_route_and_eta_trip_route,
                inputs=["bus_routes_bins", "completed_trip_ids", "reqd_eta_data"],
                outputs="joined_coordinates",
                name="left_anti_join_node",
            ),
            node(
                func=prepare_final_table,
                #inputs="joined_coordinates",
                inputs="joined_coordinates",
                outputs="joined_coordinates_with_reqd_cols",
                name="prepare_final_table_node",
            ),
        ]
    )

