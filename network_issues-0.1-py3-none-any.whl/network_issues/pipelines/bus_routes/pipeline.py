"""
This is a boilerplate pipeline 'bus_routes'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import read_bus_routes_data, create_bus_routes_bins


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=read_bus_routes_data,
                inputs="bus_routes_csv",
                outputs="bus_routes_data",
                name="read_bus_routes_data_node",
            ),
            node(
                func=create_bus_routes_bins,
                inputs="bus_routes_data",
                outputs="bus_routes_bins",
                name="create_bus_routes_bins_node",
            )
        ]
    )