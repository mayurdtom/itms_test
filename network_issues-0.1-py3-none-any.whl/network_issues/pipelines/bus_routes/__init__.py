"""
This is a boilerplate pipeline 'bus_routes'
generated using Kedro 0.18.12
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"