from dask import dataframe as dd
import pandas as pd
import h3

# CSV_PATH = "s3://network-issues/01_input/surat_bus_routes.csv"
CSV_PATH = "data/01_raw/surat_bus_routes.csv"


def _geoToH3(coords: [float, float]):
    latitude, longitude = coords
    resolution = 8
    return h3.geo_to_h3(latitude, longitude, resolution)


def read_bus_routes_data(bus_routes_df: pd.DataFrame) -> dd:
    bus_routes_df = dd.from_pandas(bus_routes_df, npartitions=1)
    bus_routes_df = bus_routes_df.loc[:, ["route_id", "latitude", "longitude"]]

    new_column_names = {"latitude": "bus_route_longitude", "longitude": "bus_route_latitude"}
    bus_routes_df = bus_routes_df.rename(columns=new_column_names)

    return bus_routes_df


def create_bus_routes_bins(bus_routes_df_with_new_cols: dd) -> dd:
    bus_routes_bins = bus_routes_df_with_new_cols.reset_index()
    bus_routes_bins = bus_routes_bins.assign(h3=bus_routes_bins.apply(lambda row: _geoToH3([row["bus_route_latitude"], row["bus_route_longitude"]]), axis=1, meta=("h3", str)))
    #bus_routes_bins = bus_routes_bins.dropna(how="any")

    return bus_routes_bins