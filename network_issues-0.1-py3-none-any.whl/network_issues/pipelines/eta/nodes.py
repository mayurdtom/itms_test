from dask.distributed import Client, LocalCluster
from dask import dataframe as dd
import numpy as np
import pandas as pd
import time
from sqlalchemy import create_engine
from sqlalchemy.sql import text, select
import psycopg2
import pytz
from datetime import datetime, timedelta
import h3
import math
import uuid

def _connect_to_postgres():
    DATABASE_USER = "postgres"
    DATABASE_PASSWORD = "timescaledbpg"
    DATABASE_HOST = "65.2.69.78"
    DATABASE_PORT = "32588"
    DATABASE_NAME = "postgresdb"

    connection_string = f"postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
    return create_engine(connection_string)


def _get_start_and_end_time():
    UTC = pytz.utc
    now_time = datetime.now(UTC)
    now = now_time - timedelta(weeks = 1)
    start_time = now.strftime("'%Y-%m-%d 00:00:00+00:00'")
    end_time = now_time.strftime("'%Y-%m-%d %H:%M:%S+00:00'")

    return start_time, end_time


def select_and_query_eta_data() -> dd:
    start_time, end_time = _get_start_and_end_time()
    eta_query = f"SELECT * FROM itms WHERE observationdatetime >= {start_time} AND observationdatetime <= {end_time} ORDER BY observationdatetime"
    eta_pandas = pd.read_sql(eta_query, con=_connect_to_postgres())
    eta = dd.from_pandas(eta_pandas, npartitions=20)
    #eta = dd.read_csv("itms_queried.csv")

    eta = eta[["trip_id", "route_id", "license_plate", "last_stop_id", "observationdatetime", "location.coordinates"]]
    eta["observationdatetime"] = eta["observationdatetime"].map(lambda x: int(datetime.strptime(str(x), "%Y-%m-%d %H:%M:%S+00:00").timestamp() * 1000000), meta=('observationtimestamp', 'i8'))
    #eta = eta.dropna()

    eta["trip_id"] = eta["trip_id"].astype(int)
    eta["last_stop_id"] = eta["last_stop_id"].astype(int)

    return eta