"""
This is a boilerplate pipeline 'eta'
generated using Kedro 0.18.12
"""

from kedro.pipeline import Pipeline, pipeline, node
from .nodes import select_and_query_eta_data


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=select_and_query_eta_data,
                inputs=None,
                outputs="reqd_eta_data",
                name="select_and_query_eta_data_node",
            )
        ]
    )