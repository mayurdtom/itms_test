from kedro.pipeline import Pipeline, node, pipeline
from .nodes import get_location_data, deep_learning_model

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([
        node(
                func = get_location_data,
                inputs = ["sensor_data", "params:deep_learning_model"],
                outputs = ["known_latlon", "unknown_latlon", "latlon"],
                name = "get_location_data",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:air_quality_index", "air_quality_index_components"],
                outputs = None,
                name = "air_quality_index_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:air_temperature", "air_temperature_components"],
                outputs = None,
                name = "air_temperature_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:ambient_noise", "ambient_noise_components"],
                outputs = None,
                name = "ambient_noise_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:atmospheric_pressure", "atmospheric_pressure_components"],
                outputs = None,
                name = "atmospheric_pressure_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:co2", "co2_components"],
                outputs = None,
                name = "co2_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:co", "co_components"],
                outputs = None,
                name = "co_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:illuminance", "illuminance_components"],
                outputs = None,
                name = "illuminance_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:no2", "no2_components"],
                outputs = None,
                name = "no2_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:o3", "o3_components"],
                outputs = None,
                name = "o3_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:pm10", "pm10_components"],
                outputs = None,
                name = "pm10_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:pm2p5", "pm2p5_components"],
                outputs = None,
                name = "pm2p5_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:precipitation", "precipitation_components"],
                outputs = None,
                name = "precipitation_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:relative_humidity", "relative_humidity_components"],
                outputs = None,
                name = "relative_humidity_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:so2", "so2_components"],
                outputs = None,
                name = "so2_deep_learning_model",
            ),
        node(
                func = deep_learning_model,
                inputs = ["known_latlon", "unknown_latlon", "params:deep_learning_model", "params:database_credentials", "params:uv", "uv_components"],
                outputs = None,
                name = "uv_deep_learning_model",
            ),
    ])

