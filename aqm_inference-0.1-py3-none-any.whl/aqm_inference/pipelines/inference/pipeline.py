from kedro.pipeline import Pipeline, node, pipeline
from .nodes import get_location_data, combine_inference_data, deep_learning_inference
from kedro.config import ConfigLoader

def create_pollutant_model_node(pollutant) -> node:
    return node(
        func=deep_learning_inference,
        inputs=["known_latlon", "unknown_latlon", "params:deep_learning_inference", "params:database_credentials", f"params:{pollutant}", f"{pollutant}_components", "start_time", "end_time"],
        outputs=None,
        name=f"{pollutant}_deep_learning_inference"
    )

def create_pipeline(**kwargs) -> Pipeline:
    nodes = [
        node(
            func=get_location_data,
            inputs=["sensor_data", "params:deep_learning_inference"],
            outputs=["known_latlon", "unknown_latlon", "latlon", "start_time", "end_time"],
            name="get_location_data"
        ),
        node(
            func=combine_inference_data,
            inputs=["params:deep_learning_inference", "params:database_credentials", "params:pollutants", "end_time"],
            outputs=None,
            name="combine_inference_data"
        ),
    ]

    config_loader = ConfigLoader(conf_source="conf")
    conf_parameters = config_loader.get("parameters*", "parameters*/**")
    pollutants = conf_parameters["pollutants"]

    for pollutant in pollutants:
        nodes.append(create_pollutant_model_node(pollutant))

    return pipeline(nodes)