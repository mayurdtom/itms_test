from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, BatchNormalization
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.optimizers.legacy import Nadam
from tensorflow.keras.datasets import mnist
from tensorflow.keras import backend as K
from tensorflow.keras import losses
from tensorflow.keras import metrics
from tensorflow.keras import initializers
from keras.callbacks import EarlyStopping
import tensorflow as tf
from keras import Input
from sklearn.preprocessing import LabelBinarizer
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error as mae
from sklearn.decomposition import PCA
from typing import Dict, Tuple
import numpy as np
import pandas as pd
import dask.dataframe as dd
from dask import delayed
import psycopg2
from prophet import Prophet
from datetime import datetime, timedelta
import dask.array as da
import pytz

import h3
from geojson import Feature
import json

from minio import Minio
import tempfile
import os
import shutil
from tensorflow.keras.models import load_model
from sqlalchemy import create_engine

def get_location_data(sensor_data: pd.DataFrame, parameters: Dict) -> Tuple:
    known_latlon = pd.DataFrame(data=sensor_data.set_index('device_id')[['latitude', 'longitude']].values, columns=['latitude', 'longitude'])
    #known_latlon = known_latlon.drop_duplicates()
    # Define boundaries of the interpolation field
    # Minimum latitude value
    lat_min = min(known_latlon['latitude'])
    # Maximum latitude value
    lat_max = max(known_latlon['latitude'])
    # Minimum longitude value
    lng_min = min(known_latlon['longitude'])
    # Maximum longitude value
    lng_max = max(known_latlon['longitude'])
    # Value of extension to the grid
    ext = parameters["ext"]
    # Grid Length
    grid_length = parameters["grid_length"]
    
    # Get 100 longitude values between maximum and minimum longitude values
    xx = np.linspace(lng_min-ext, lng_max+ext, grid_length)
    # Get 100 latitude values between maximum and minimum latitudes values
    yy = np.linspace(lat_min-ext, lat_max+ext, grid_length)

    # Get grid with arrays xx and yy
    unknown_set = np.meshgrid(xx, yy)
    
    # Array of all longitude values in the grid
    gridx = np.reshape(unknown_set[0], (1, grid_length*grid_length))
    # Array of all latitude values in the grid
    gridy = np.reshape(unknown_set[1], (1, grid_length*grid_length))

    # Concatenate latitude and longitude arrays
    gridyx = np.concatenate((gridy.T, gridx.T), axis=1)
    
    # Define an empty DataFrame for unknown latitude and longitude values
    unknown_latlon = pd.DataFrame(columns = ['latitude', 'longitude'])
    # Assign Concatenated latitude and longitude array to unknown latitude longitude DataFrame
    unknown_latlon[['latitude', 'longitude']] = gridyx

    # Concatenate both known and Unknown lat lon DataFrame with new index
    latlon = pd.concat([known_latlon, unknown_latlon], ignore_index = True)
    
    known_latlon = dd.from_pandas(known_latlon, npartitions=1)
    unknown_latlon = dd.from_pandas(unknown_latlon, npartitions=1)
    latlon = dd.from_pandas(latlon, npartitions=1)
    
    # Returns known, unknown, and combined location DataFrames
    return known_latlon, unknown_latlon, latlon

def forecast_sensor_data(sensor_data, sensor_column):
    sensor_data = sensor_data.compute()
    interval_width = 1
    changepoint_range = 1
    # Model instatiation with Prophet object enforcing daily, weekly, and yearly seasonalities.
    m = Prophet(daily_seasonality = True, yearly_seasonality = True, weekly_seasonality = True,
                seasonality_mode = 'additive',
                interval_width = interval_width,
                changepoint_range = changepoint_range)

    sensor_data = sensor_data.rename(columns={'observationdatetime': 'ds', sensor_column: 'y'})
    
    # Fit the model to the data
    m = m.fit(sensor_data)

    future = m.make_future_dataframe(periods=96, freq='15min')

    forecast = m.predict(future)

    # Extract relevant columns from the forecast
    forecast = forecast[['ds', 'yhat']]
    forecast = forecast.rename(columns={'ds': 'observationdatetime', 'yhat': sensor_column})
    forecast = dd.from_pandas(forecast, npartitions=2)
    return forecast

def pollutant_data_preprocessing(pollutant_data):
    time_series_data = pollutant_data.drop(columns=['observationdatetime'])
    time_series_data = time_series_data.to_dask_array().T
    spatio_temporal_observations_data = time_series_data
    data_scaler = StandardScaler()
    data_scaler.fit(spatio_temporal_observations_data)
    spatio_temporal_observations = data_scaler.transform(spatio_temporal_observations_data)
    spatio_temporal_observations = da.from_array(spatio_temporal_observations, chunks=int(len(spatio_temporal_observations)/4))
    return spatio_temporal_observations, data_scaler, time_series_data

def run_pca(spatio_temporal_observations, cmpnts):
    K = min(spatio_temporal_observations.shape[1], spatio_temporal_observations.shape[0]-1)
    pca = PCA(n_components=K)
    pca.fit(spatio_temporal_observations)
    alpha_k_ = da.dot(pca.components_[:cmpnts], spatio_temporal_observations.T)
    coff_scaler = StandardScaler()
    coff_scaler.fit(alpha_k_.T)
    alpha_k = coff_scaler.transform(alpha_k_.T)
    alpha_k = da.from_array(alpha_k, chunks=int(len(alpha_k)/4))
    return alpha_k, cmpnts, coff_scaler, pca

def geoToH3(latitude,longitude):
    resolution = 9
    return h3.geo_to_h3(latitude, longitude, resolution)

def hex_id_to_geojson(hex_id):
    hexagon = h3.h3_to_geo_boundary(hex_id, geo_json=True)
    
    feature = {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [hexagon]
        },
        "properties": {}
    }
    return json.dumps(feature)

def deep_learning_model(known_latlon: pd.DataFrame, unknown_latlon: pd.DataFrame, parameters: Dict, params_creds, pollutant, components):
    IST = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(IST)
    end_time = current_time.replace(hour=0, minute=0, second=0, microsecond=0)
    start_time = end_time - timedelta(days=parameters["past_data_range"])
    start_time = start_time.strftime("'%Y-%m-%d %H:%M:%S'")
    end_time = end_time.strftime("'%Y-%m-%d %H:%M:%S'")
    conn = psycopg2.connect(host=params_creds["creds"]["host"], port=params_creds["creds"]["port"], database=params_creds["creds"]["database"], user=params_creds["creds"]["user"], password=params_creds["creds"]["password"])
    cursor = conn.cursor()
    sql_query = """SELECT * from agra_aqm_{}_imputated_data where observationdatetime >= {} and observationdatetime < {}""".format(pollutant, start_time, end_time)
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    column_names = [desc[0] for desc in cursor.description]
    pollutant_data_df = pd.DataFrame(rows, columns=column_names)
    cursor.close()
    conn.close()
    pollutant_data = dd.from_pandas(pollutant_data_df, npartitions=2)
    
    # Forecasting
    forecast_results = []
    for sensor_column in pollutant_data.columns[1:]:
        sensor_data = pollutant_data[['observationdatetime', sensor_column]]
        forecast = forecast_sensor_data(sensor_data, sensor_column)
        forecast_results.append(forecast)
    forecast_df = dd.concat(forecast_results)
    forecast_df = dd.concat([df.set_index('observationdatetime') for df in forecast_results], axis=1)
    forecast_df = forecast_df.reset_index()

    pollutant_data = forecast_df
    
    # Data Preprocessing
    spatio_temporal_observations, data_scaler, time_series_data = pollutant_data_preprocessing(pollutant_data)
    
    # PCA
    alpha_k, components, coff_scaler, pca = run_pca(spatio_temporal_observations, components)
    
    # Get Model
    minio_client = Minio(parameters["minio_url"],
                 access_key=parameters["minio_access_key"],
                 secret_key=parameters["minio_secret_key"],
                 secure=False)
    bucket_name = 'aqm-interpolation-model-training'
    path_to_model_folder = '02_Models/{}_model.h5'.format(pollutant)
    temp_dir = tempfile.mkdtemp(prefix='minio_temp_')
    objects = minio_client.list_objects(bucket_name, prefix=path_to_model_folder, recursive=True)
    for obj in objects:
        file_path = obj.object_name
        relative_path = os.path.relpath(file_path, path_to_model_folder)
        destination_path = os.path.join(temp_dir, relative_path)
        minio_client.fget_object(bucket_name, file_path, destination_path)
    model = load_model(temp_dir)

    # Fit on new data
    model.fit(known_latlon.to_dask_array().compute(), # input data
              alpha_k.compute(), # target data
              batch_size=parameters["batch_size"], # Number of samples per gradient update. If unspecified, batch_size will default to 32.
              epochs=parameters["epochs"]) # Number of epochs
    
    pred_intr_op = model.predict(unknown_latlon.to_dask_array().compute(), batch_size = parameters["intr_batch_size"])
    shutil.rmtree(temp_dir)
    pred_intr = coff_scaler.inverse_transform(pred_intr_op)
    pred_intr_coeff = np.dot(pred_intr, pca.components_[:components])
    Interpolated_Data = data_scaler.inverse_transform(pred_intr_coeff)
    Whole_Data = np.concatenate((Interpolated_Data, time_series_data.compute()), axis = 0)
    Binned_Data = pd.DataFrame(Whole_Data)
    Binned_Data = Binned_Data.iloc[:, -96:]
    Binned_Data[['latitude','longitude']] = pd.concat([unknown_latlon.compute(), known_latlon.compute()]).reset_index().drop('index', axis = 1)
    Binned_Data['hex_id'] = Binned_Data.apply(lambda row : geoToH3(row['latitude'],row['longitude']), axis = 1)
    Binned_Data.drop(columns=['latitude', 'longitude'], inplace=True)
    Binned_Data = Binned_Data.groupby('hex_id').mean().reset_index()
    Binned_Data['geojson'] = Binned_Data['hex_id'].apply(hex_id_to_geojson)
    Binned_Data.drop(columns=['hex_id'], inplace=True)
    Binned_Data.rename(columns={old_col: 'col_' + str(i) for i, old_col in enumerate(Binned_Data.columns[:96])}, inplace=True)
    melted_df = pd.melt(Binned_Data, id_vars='geojson', 
                    value_vars=[f'col_{i}' for i in range(0, 96)], 
                    var_name='col_no', 
                    value_name='pollutant_val')
    IST = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(IST)
    start_time = current_time.replace(hour=0, minute=0, second=0, microsecond=0)
    end_time = start_time + timedelta(days=1)  - timedelta(minutes=15)
    start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
    end_time = end_time.strftime('%Y-%m-%d %H:%M:%S')
    datetime_index = pd.DatetimeIndex(pd.date_range(start=start_time, end=end_time, freq='15T'))
    datetime_index.name = 'observationdatetime'
    grouped_data = melted_df.groupby('geojson')
    df_list = []
    for i, grp in grouped_data:
        df = grp.sort_values(by=['col_no'])
        df['observationdatetime'] = datetime_index
        df_list.append(df)
    concatenated_df = pd.concat(df_list, axis=0, ignore_index=True)
    concatenated_df.drop(columns=['col_no'], inplace=True)
    database_url = parameters["postgres_conn_string"]
    engine = create_engine(database_url)
    table_name = "agra_aqm_{}_inference_data".format(pollutant)
    concatenated_df.to_sql(table_name, engine, if_exists="replace", index=False)
    return None

