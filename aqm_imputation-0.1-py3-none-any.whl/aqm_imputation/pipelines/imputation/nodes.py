import dask.dataframe as dd
import dask.array as da
import numpy as np
from datetime import datetime, timedelta, timezone
from typing import Dict, Tuple, Any
from prophet import Prophet
import altair as alt
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge, Ridge
import logging
logger = logging.getLogger('cmdstanpy')
logger.addHandler(logging.NullHandler())
logger.propagate = False
logger.setLevel(logging.CRITICAL)
import warnings
warnings.filterwarnings('ignore')
from tqdm import tqdm
from dask import delayed
import dask
import pytz
from datetime import timedelta
import psycopg2
from sqlalchemy import create_engine
import pandas as pd
import pytz

def detect_anomalies(sensor_data: dd.DataFrame, pollutant):
    interval_width = 1
    changepoint_range = 1
    pollutant_row_count = sensor_data[pollutant].count().compute()
    pollutant_total_null_rows = sensor_data[pollutant].isna().sum().compute()
    condition = (pollutant_row_count > 2) and (pollutant_row_count - pollutant_total_null_rows) > 0.2 * len(sensor_data)
    if condition:
        m = Prophet(daily_seasonality = True, yearly_seasonality = True, weekly_seasonality = True,
                    seasonality_mode = 'additive',
                    interval_width = interval_width,
                    changepoint_range = changepoint_range)
        sensor_data_copy = sensor_data[['observationdatetime', pollutant]].copy()
        sensor_data_copy['observationdatetime'] = sensor_data_copy['observationdatetime'].dt.tz_localize(None)
        sensor_data_copy['ds'] = sensor_data_copy['observationdatetime']
        sensor_data_copy['y'] = sensor_data_copy[pollutant]
        sensor_data_copy = sensor_data_copy[['ds', 'y']]
        sensor_data_copy = sensor_data_copy.compute()
        m.fit(sensor_data_copy[['ds', 'y']])
        forecast = m.predict(sensor_data_copy[['ds', 'y']])
        forecast['y'] = sensor_data_copy['y'].values
        forecast['anomaly'] = 0
        forecast.loc[forecast['y'] > forecast['yhat_upper'], 'anomaly'] = 1
        forecast.loc[forecast['y'] < forecast['yhat_lower'], 'anomaly'] = -1

        forecast.loc[forecast['anomaly'] != 0, 'y'] = np.nan
        forecast['observationdatetime'] = forecast['ds']
        forecast[pollutant] = forecast['y']
        forecast = forecast[['observationdatetime', pollutant]]
        forecast = dd.from_pandas(forecast, npartitions=4)
    else:
        forecast = sensor_data[['observationdatetime', pollutant]].copy()
    return forecast

def datetime_preprocessing(parameters: Dict, params_creds: Dict) -> Tuple[dd.DataFrame, Any, Any]:
    IST = pytz.timezone('Asia/Kolkata')
    current_time = datetime.now(IST)
    end_time = current_time.replace(second=0, microsecond=0) - timedelta(minutes=current_time.minute % 15)
    end_time_datetimeindex = end_time - timedelta(minutes=15)
    start_time = end_time - timedelta(days=1)
    start_time = start_time.strftime("'%Y-%m-%d %H:%M:%S'")
    end_time = end_time.strftime("'%Y-%m-%d %H:%M:%S'")
    end_time_datetimeindex = end_time_datetimeindex.strftime("'%Y-%m-%d %H:%M:%S'")
    "Read data from TimescaleDB"
    conn = psycopg2.connect(host=params_creds["creds"]["host"], port=params_creds["creds"]["port"], database=params_creds["creds"]["database"], user=params_creds["creds"]["user"], password=params_creds["creds"]["password"])
    cursor = conn.cursor()
    sql_query = """SELECT * from agra_aqm where observationdatetime > {} AND observationDateTime <= {} ORDER BY observationDateTime""".format(start_time,end_time)
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    column_names = [desc[0] for desc in cursor.description]
    df = pd.DataFrame(rows, columns=column_names)
    cursor.close()
    conn.close()
    preprocessed_raw_data = dd.from_pandas(df, npartitions=2)
    preprocessed_raw_data['observationdatetime'] = dd.to_datetime(preprocessed_raw_data['observationdatetime']).dt.tz_localize(None)
    preprocessed_raw_data = preprocessed_raw_data[parameters["column_order"]]

    alt.data_transformers.disable_max_rows()

    grouped_data = preprocessed_raw_data.groupby('device_id')
    pollutant_columns = preprocessed_raw_data.columns[5:]
    processed_data = []
    unique_ids = preprocessed_raw_data['device_id'].unique().compute()
    unique_ids = unique_ids.to_list()

    for unique_id in tqdm(unique_ids):
        group = grouped_data.get_group(unique_id)
        single_sensor_data = []
        for pollutant in pollutant_columns:
            single_sensor_data.append(detect_anomalies(group, pollutant))
        processed_data.append(single_sensor_data)

        concat_dfs = []
    for i in range(len(processed_data)):
        concat_dfs.append(dd.concat([df.set_index('observationdatetime') for df in processed_data[i]], axis=1))

    for df, unique_id in zip(concat_dfs, unique_ids):
        df['device_id'] = unique_id

    concatenated_df = dd.concat(concat_dfs, axis=0, ignore_index=True)
    concatenated_df = concatenated_df.reset_index()
    concatenated_df = concatenated_df.compute()

    return concatenated_df, start_time, end_time_datetimeindex

@delayed
def sync_group(unique_id, grp, datetime_index):
    if grp.empty:
        resampled_data = pd.DataFrame(index=datetime_index)
        new_cols = ['air_quality_index', 'co', 'pm10', 'pm2p5', 'co2', 
                    'precipitation', 'so2', 'no2', 'o3', 'uv', 'air_temperature', 'atmospheric_pressure', 
                    'illuminance', 'relative_humidity', 'ambient_noise']
        resampled_data[new_cols] = np.nan
        resampled_data['device_id'] = unique_id
        resampled_data['device_status'] = 'ACTIVE'
        resampled_data['air_quality_level'] = np.nan
        resampled_data['aqi_major_pollutant'] = np.nan
        resampled_data.reset_index(inplace=True)
        return resampled_data
    else:
        grp['observationdatetime'] = grp['observationdatetime'].dt.tz_localize(None)
        grp['observationdatetime'] = pd.to_datetime(grp['observationdatetime'])
        grp.set_index('observationdatetime', inplace=True)
        resampled_data = grp.resample('15T').mean()
        resampled_data = resampled_data.reindex(datetime_index)
        resampled_data['device_id'] = unique_id
        resampled_data['device_status'] = 'ACTIVE'
        resampled_data['air_quality_level'] = np.nan
        resampled_data['aqi_major_pollutant'] = np.nan
        resampled_data.reset_index(inplace=True)
        return resampled_data

def run_datetime_synchronization(start_time, end_time_datetimeindex, processed_data: pd.DataFrame, parameters: Dict) -> dd.DataFrame:
    unique_ids = ['LM01P0024S', 'LM01P0011S', 'LM01P0026S', 'LM01P0002S', 'LM01P0009S', 'LM01P0015S',
                  'LM01P0030S', 'LM01P0032S', 'LM01P0001S', 'LM01P0029S', 'LM01P0038S', 'LM01P0008S',
                  'LM01P0019S', 'LM01P0022S', 'LM01P0020S', 'LM01P0016S', 'LM01P0039S', 'LM01P0028S']
    start_time = start_time.replace("'", "")
    end_time_datetimeindex = end_time_datetimeindex.replace("'", "")
    datetime_index = pd.DatetimeIndex(pd.date_range(start=start_time, end=end_time_datetimeindex, freq='15T'))
    datetime_index.name = 'observationdatetime'
    processed_data = dd.from_pandas(processed_data, npartitions=2)

    processed_data['observationdatetime'] = dd.to_datetime(processed_data['observationdatetime'])
    grouped_data = processed_data.groupby('device_id')

    delayed_objects = []
    for unique_id in tqdm(unique_ids):
        group = grouped_data.get_group(unique_id)
        delayed_objects.append(sync_group(unique_id, group, datetime_index))
    combined_dask_df = dd.from_delayed(delayed_objects)
    combined_dask_df = combined_dask_df[parameters["column_order"]]
    combined_dask_df = combined_dask_df.compute()
    return combined_dask_df

def get_imputated_pollutant_data(time_synchronized_data, parameters: Dict, params_creds: Dict):
    num_unique_ids = time_synchronized_data.device_id.nunique()
    num_of_observations = int(len(time_synchronized_data)/num_unique_ids)
    unique_ids = time_synchronized_data['device_id'].unique()
    unique_ids = list(unique_ids)
    for id in unique_ids:
        datetime_index = time_synchronized_data[time_synchronized_data['device_id'] == id]
        break
    imp_br_model = IterativeImputer(random_state=0, estimator=BayesianRidge(), max_iter=parameters["maximum_iterations"], tol=parameters["tolerance"])
    db_params = params_creds["creds"]
    conn = psycopg2.connect(**db_params)
    cursor = conn.cursor()
    for column in time_synchronized_data.columns[5:]:
        np_array = time_synchronized_data[column].values.reshape((num_of_observations, num_unique_ids))
        imputated_data = imp_br_model.fit_transform(np_array)
        pollutant_data = pd.DataFrame(imputated_data, columns=list(['sensor_'+str(i) for i in unique_ids]))
        pollutant_data['observationdatetime'] = datetime_index['observationdatetime']
        max_observation_datetime = pollutant_data.observationdatetime.max()
        filtered_df = pollutant_data[pollutant_data['observationdatetime'] == max_observation_datetime]
        for _, row in filtered_df.iterrows():
            insert_query = f"INSERT INTO agra_aqm_{column}_imputated_data ({', '.join(filtered_df.columns)}) VALUES ({', '.join(['%s'] * len(filtered_df.columns))})"
            row = [float('nan') if pd.isna(val) else val for val in row]
            cursor.execute(insert_query, tuple(row))
        conn.commit()
    cursor.close()
    conn.close()
    return None
