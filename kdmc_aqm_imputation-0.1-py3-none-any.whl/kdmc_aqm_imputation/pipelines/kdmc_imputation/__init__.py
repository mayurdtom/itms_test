"""
This is a boilerplate pipeline 'kdmc_imputation'
generated using Kedro 0.18.9
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
