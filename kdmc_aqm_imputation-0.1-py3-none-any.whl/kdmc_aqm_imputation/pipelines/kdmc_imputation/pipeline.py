from kedro.pipeline import Pipeline, node, pipeline
from .nodes import datetime_preprocessing, run_datetime_synchronization, get_imputated_pollutant_data

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([
        node(
                func = datetime_preprocessing,
                inputs = ["params:initializations", "params:database_credentials"],
                outputs = ["preprocessed_raw_data", "start_time", "end_time_datetimeindex", "end_time_ts"],
                name = "datetime_preprocessing",
            ),
        node(
                func = run_datetime_synchronization,
                inputs = ["start_time", "end_time_datetimeindex", "preprocessed_raw_data", "params:initializations"],
                outputs = "time_synchronized_data",
                name = "run_datetime_synchronization",
            ),
        node(
                func = get_imputated_pollutant_data,
                inputs = ["time_synchronized_data", "params:imputer_options", "params:database_credentials", "end_time_ts"],
                outputs = None,
                name = "get_imputated_pollutant_data",
            ),
    ])