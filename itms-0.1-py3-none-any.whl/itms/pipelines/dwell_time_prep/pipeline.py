"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.18.4
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import dwell_time_calc, avg_dwell_time_calc
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=dwell_time_calc,
                inputs=["mmr_h3_segments", "mmr_segments"],
                outputs="dwelltime_df",
                name="dwell_time_calc",
            ),
            node(
                func=avg_dwell_time_calc,
                inputs="dwelltime_df",
                outputs="pandas_avg_dwelltime_df",
                name="avg_dwell_time_calc",
            ),
        ]
    )