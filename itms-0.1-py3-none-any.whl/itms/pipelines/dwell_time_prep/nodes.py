import pandas as pd
import numpy as np
import folium
import geopy.distance
import json
from shapely.geometry import LineString, Point
import matplotlib.pyplot as plt
import math
from shapely.ops import shared_paths
import shapely
import pickle as pkl
import cvxpy as cvo
# from pyproj import Geod
from datetime import datetime,timedelta
import h3
# import geopandas
import rdp
import seaborn as sns
from tqdm import tqdm
from haversine import haversine, Unit
import datetime
import pytz
from itertools import product
import psycopg2
import dask.dataframe as dd

import logging

log = logging.getLogger(__name__)

def h3ToGeoJson(h3_hash):
    # return '{"type": "FeatureCollection","features": [{"type": "Feature","properties": {},"geometry": {"type": "Polygon","coordinates": ['+str(h3.h3_set_to_multi_polygon([h3_hash], geo_json=True)[0][0])+']}}]}'
    return  '{"type": "Polygon", "coordinates": ['+ str(h3.h3_set_to_multi_polygon([h3_hash], geo_json=True)[0][0]) +'] }'

def geoToH3(latitude, longitude):
    resolution = 8
    return h3.geo_to_h3(latitude, longitude, resolution)

def geoToH3HighResolution(latitude, longitude):
    resolution = 14
    return h3.geo_to_h3(latitude, longitude, resolution)
    
def getH3Dist(p1, p2):
    # this is an approximate multiplication value**
    return h3.h3_distance(geoToH3HighResolution(p1[0], p1[1]), geoToH3HighResolution(p2[0], p2[1]))*0.001348575

def Euclidean(p1, p2):
    return (((p1[0]-p2[0])**2)+((p1[1]-p2[1])**2))**0.5

def geo_to_segment(latitude,longitude,h3_to_seg,new_segment_dict):
    h3_resolution=11 # edge length approx. 25 meters
    hid=h3.geo_to_h3(latitude,longitude,h3_resolution)
    notfound=True
    k=0
    hex_seg=hid
    while(notfound):
        ring=h3.k_ring(hid,k)
        for nh in ring:
            if nh in list(h3_to_seg.keys()):
                hex_seg=nh
                notfound=False
                break
        k+=1
        if k>5:
            return -1
    segment_ids=h3_to_seg[hex_seg]
    if len(segment_ids)==1:
        return segment_ids[0]
    distances=[]
    for i in range(len(segment_ids)):
        sid=segment_ids[i]
        distances.append(min([(((c[0]-longitude)**2)+((c[1]-latitude)**2))**0.5 for c in new_segment_dict[sid]['coordinates']]))
    return segment_ids[distances.index(min(distances))]

def dwell_time_calc(h3_to_seg, segment_dict):
    new_segment_dict={}
    for segid,segment in segment_dict.items():
        new_segment_dict[segid]={
            "coordinates":list(segment.exterior.coords),
            "length": segment.exterior.length/2,
            "polygon": segment
        }

    h3_resolution=11 # edge length approx. 25 meters
    day = 24
    day_to_key = {}
    for i in range(7):
        day_to_key[i] = day*i
    
    # Load data from postgres
    conn = psycopg2.connect(host="timescaledb-pgbouncer.dbspace", port=5432, database="postgresdb", user="postgres", password="timescaledbpg")
    cursor = conn.cursor()
    # sql_query = """SELECT observationdatetime, license_plate, trip_id, route_id, trip_direction, "location.coordinates" FROM itms where observationdatetime > DATE(CURRENT_TIMESTAMP - Interval '30 days') and observationdatetime <= CURRENT_TIMESTAMP;"""
    sql_query = """SELECT observationdatetime, license_plate, trip_id, route_id, trip_direction, "location.coordinates" FROM itms where observationdatetime > DATE(CURRENT_TIMESTAMP - Interval '6 Hours') and observationdatetime <= CURRENT_TIMESTAMP;"""
    
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    column_names = [desc[0] for desc in cursor.description]
    eta = pd.DataFrame(rows, columns=column_names)
    cursor.close()
    conn.close()

    eta['longitude']=eta['location.coordinates'].apply(lambda x:x.strip('()').split(',')[0])
    eta['latitude']=eta['location.coordinates'].apply(lambda x:x.strip('()').split(',')[-1])
    eta['longitude'] = eta['longitude'].astype(float)
    eta['latitude'] = eta['latitude'].astype(float)

    new_df_list = []
    no_segment_misses, less_message_misses, segment_dist_misses, zero_dwell_time_misses = 0, 0, 0, 0

    for trip in tqdm(eta["trip_id"].unique()):
        trip_df = eta[eta["trip_id"] == trip].reset_index(drop=True)
        route_id=trip_df['route_id'][0]
        trip_direction=trip_df['trip_direction'][0]
        trip_df = trip_df.loc[:, ["observationdatetime", "latitude", "longitude"]]
        trip_df = trip_df.sort_values("observationdatetime").reset_index(drop=True)
        
        # CALCULATE HASH VALUE FOR EACH LAT LONG PAIR FOR A PARTICULAR TRIP
        segment_col = []
        for i in range(len(trip_df)):
            segment_col.append(geo_to_segment(trip_df["latitude"][i], trip_df["longitude"][i], h3_to_seg, new_segment_dict))
        trip_df["segment"] = segment_col
        
        # FOR EVERY HASH VALUE FIND THE DWELL_TIME: THE DIFFERENCE OF FIRST AND LAST 'OBSERVATION_TIME'
        for segment in trip_df["segment"].unique():
            if segment==-1:
                no_segment_misses+=1
                continue
            segment_df = trip_df[trip_df["segment"] == segment].reset_index(drop=True)
            segment_df = segment_df.sort_values("observationdatetime").reset_index(drop=True)
            
            # IF THE DATA HAS LESS THEN 5 MESSAGES PER HEXAGON, THEN IGNORE THAT ROW
            if len(segment_df) < 2:
                less_message_misses+=1
                continue
                
            # FIND THE 'DWELL_TIME' BY TAKING THE DIFFERENFE OF LAST AND FIRST 'OBSERVATION_TIME'  
            segment_start = segment_df.iloc[[0]]
            segment_end = segment_df.iloc[[-1]].reset_index(drop=True)
            
            # FINDING DISTANCE
            segment_dist = Euclidean([segment_start["latitude"][0], segment_start["longitude"][0]], [segment_end["latitude"][0], segment_end["longitude"][0]])

            # ELIMINATE DISTANCE BASED NOISE
            if segment_dist <= 1.5e-5:
                segment_dist_misses+=1
                continue
            
            # CALCULATE DWELL TIME
            segment_start_time = pd.to_datetime(segment_start["observationdatetime"].values[0])
            segment_end_time = pd.to_datetime(segment_end["observationdatetime"].values[0])
            travel_time = (segment_end_time - segment_start_time)/np.timedelta64(1,'s')
            
            travel_speed=segment_dist/travel_time
            
            dwell_time=new_segment_dict[segment]['length']/travel_speed
            
            # IGNORE THE ROWS WITH DWELL TIME EQUAL TO ZERO
            if dwell_time == 0.0:
                zero_dwell_time_misses+=1
                continue
                
            # GENERATE THE WEEK SLOT USING OBSERVATION TIME
            day_of_week = pd.to_datetime(segment_start["observationdatetime"][0]).dayofweek
            day_of_week = day_to_key[day_of_week]
            
            start_hour_slot = pd.to_datetime(segment_start["observationdatetime"][0]).hour
            end_hour_slot = pd.to_datetime(segment_end["observationdatetime"][0]).hour
                
            # IF THERE ARE MULTIPLE TIME SLOTS, THEN GENERATE SEPERATE ROWS FOR EACH
            if start_hour_slot != end_hour_slot:
                for hour in range(start_hour_slot, end_hour_slot+1):
                    time_slot = day_of_week + hour
                    new_df_list.append({"observed_time": segment_start_time,
                                        "route_id":route_id,
                                        "trip_direction":trip_direction,
                                        "segment": segment,
                                        "time_slot": time_slot,
                                        "dwell_time": dwell_time,
                                    })
            else:
                time_slot = day_of_week + start_hour_slot
                new_df_list.append({"observed_time": segment_start_time,
                                    "route_id":route_id,
                                    "trip_direction":trip_direction,
                                    "segment": segment,
                                    "time_slot": time_slot,
                                    "dwell_time": dwell_time})
    new_df = pd.DataFrame(new_df_list)
    # Convert pandas DataFrame to Dask DataFrame
    new_df = dd.from_pandas(new_df, npartitions=4)
    return new_df

def avg_dwell_time_calc(new_df):
    new_df = new_df.compute()
    road_segments = []
    dwell_time_df_list = []

    current_date = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    add_days = datetime.timedelta(days=1)
    subtract_days = datetime.timedelta(days=31)
    end_time = current_date + add_days
    start_time = end_time - subtract_days

    timezone_ist = pytz.timezone('UTC')
    start_time = pd.Timestamp(start_time, tz=timezone_ist)
    end_time = pd.Timestamp(end_time, tz=timezone_ist)

    new_df['observed_time'] = pd.to_datetime(new_df['observed_time'])

    new_df['avg_dwell_time'] = np.where(
        (new_df['observed_time'] > start_time.to_datetime64()) & (new_df['observed_time'] <= end_time.to_datetime64()),
        new_df['dwell_time'],
        np.nan
    )
    
    for name, group in tqdm(new_df.groupby(by=['segment'])):
        group_avg_dtime = group.groupby(pd.Grouper(key='observed_time', freq='1H'))['avg_dwell_time'].mean().reset_index()

        for _, row in group_avg_dtime.iterrows():
            dwell_time_df_list.append({
                'segment': int(name),
                'start': row['observed_time'],
                'end': row['observed_time'] + pd.DateOffset(hours=1),
                'avg_dwell_time': row['avg_dwell_time']
            })
            road_segments.append(int(name))
    
    dwelltime_df = pd.DataFrame(dwell_time_df_list)
    dwelltime_df['avg_dwell_time'] = dwelltime_df['avg_dwell_time'].fillna(-1)
    dwelltime_df = dwelltime_df.drop('end', axis=1)

    # Get unique hours
    all_hours = pd.date_range(start=start_time, end=end_time, freq='H')

    # Create all combinations of segments and hours
    segments = dwelltime_df['segment'].unique()
    all_combinations = pd.DataFrame(list(product(segments, all_hours)), columns=['segment', 'start'])

    # Convert the 'date_column' to datetime64[ns]
    all_combinations['start'] = pd.to_datetime(all_combinations['start']).dt.tz_convert(None)

    # Merge with original DataFrame
    merged_df = pd.merge(all_combinations, dwelltime_df, on=['segment', 'start'], how='left')

    # Replace missing values with -1
    merged_df['avg_dwell_time'] = merged_df['avg_dwell_time'].fillna(-1)

    # Sort by segment and start time
    merged_df.sort_values(['segment', 'start'], inplace=True)

    # Reset index if needed
    merged_df.reset_index(drop=True, inplace=True)
    merged_df = dd.from_pandas(merged_df, npartitions=4)

    return merged_df