from kedro.pipeline import Pipeline, node, pipeline

from .nodes import preprocess_data
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=preprocess_data,
                inputs=["mmr_segments", "avg_dwelltime_df"],
                outputs=["dwell_time_preprocessed_data", "adjacency_matrix", "preprocessed_segments",
                         "segments_visualize"],
                name="preprocess_data_node",
            ),
        ]
    )
