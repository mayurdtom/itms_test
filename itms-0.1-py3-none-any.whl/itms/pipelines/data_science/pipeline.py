"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.18.4
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import train_test_split_data, train_tgcn_model, evaluate_model
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=train_test_split_data,
                inputs=["dwell_time_preprocessed_data", "params:train_test_split_options"],
                outputs=["X_train", "y_train", "X_test", "y_test", "test_ex_per_hour"],
                name="train_test_split_node",
            ),
            node(
                func=train_tgcn_model,
                inputs=["X_train", "y_train", "X_test", "y_test",
                        "adjacency_matrix", "preprocessed_segments", "params:model_options"],
                outputs=["tgcn_model", "preprocessed_y_true", "preprocessed_y_pred"],
                name="train_model_node",
            ),
            node(
                func=evaluate_model,
                inputs=["preprocessed_y_true", "preprocessed_y_pred",
                        "test_ex_per_hour", "segments_visualize", "preprocessed_segments"],
                outputs=["metrics", "hex_evaluation_plot"],
                name="evaluate_model_node",
            ),
        ]
    )