"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.18.4
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
