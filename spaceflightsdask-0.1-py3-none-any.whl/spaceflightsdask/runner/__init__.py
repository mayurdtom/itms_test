from .dask_runner import DaskRunner

__all__ = ["DaskRunner"]
__version__ = "0.1"