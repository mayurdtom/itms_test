from kedro.pipeline import Pipeline, node, pipeline

from .nodes import sequence_data_preparation, inference
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=sequence_data_preparation,
                inputs="dwell_time_preprocessed_data",
                outputs="sequence_data",
                name="sequence_data_preparation",
            ),
            node(
                func=inference,
                inputs=["sequence_data", "adjacency_matrix", "preprocessed_segments", "segments_visualize", "time_now", "real_dwell_time"],
                outputs=None,
                name="inference",
            ),
        ]
    )
