from kedro.pipeline import Pipeline, node, pipeline

from .nodes import preprocess_data
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=inference,
                inputs=["dwell_time_preprocessed_data", "adjacency_matrix", "preprocessed_segments", "segments_visualize", "time_now"],
                outputs=["predictions"],
                name="inference",
            ),
        ]
    )
