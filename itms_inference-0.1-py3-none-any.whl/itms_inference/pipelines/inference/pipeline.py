from kedro.pipeline import Pipeline, node, pipeline

from .nodes import sequence_data_preparation, inference
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=inference,
                inputs=["dwell_time_preprocessed_data", "adjacency_matrix", "preprocessed_segments", "segments_visualize", "time_now", "new_segment_dict", "max_time_eta"],
                outputs=None,
                name="inference",
            ),
        ]
    )
