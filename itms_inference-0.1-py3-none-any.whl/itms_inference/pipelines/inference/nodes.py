"""
This is a boilerplate pipeline 'inference'
generated using Kedro 0.18.9
"""
from minio import Minio
import time
import datetime 
import pytz
import h3
import pandas as pd
import calendar
import pickle
import numpy as np
from tqdm import tqdm
# import h3pandas
import os
import tensorflow as tf
from tensorflow.keras.layers import Input,Dense,Reshape,LSTM, Dropout
from tensorflow.keras.models import Model
from spektral.layers import GCNConv
from spektral.utils import gcn_filter
import folium
from shapely.geometry import Point
# import geopandas as gpd
import tempfile
import os
import shutil

def unscale_data(data_scaled):
    max_time=500
    min_time=-1
    data_unscaled=(data_scaled*(max_time-min_time))+min_time
    return data_unscaled

def clean_prediction(prediction):
    for i in range(prediction.shape[0]):
        for j in range(prediction.shape[1]):
            if prediction[i,j]<0:
                prediction[i,j]=-1
    return prediction

def inference(data, adj_lap, segments, segments_visualize, time_now, parameters: Dict) -> Tuple:
    minio_client = Minio('minio-service.minio:9000',
                     access_key='miniouser',
                     secret_key='kjjAFEFvojiiy673nsn',
                     secure=False)
    bucket_name = 'itms-trip-delay'
    path_to_model_folder = '04_models/tgcn_model.h5'
    temp_dir = tempfile.mkdtemp(prefix='minio_temp_')
    objects = minio_client.list_objects(bucket_name, prefix=path_to_model_folder, recursive=True)
    for obj in objects:
        file_path = obj.object_name
        relative_path = os.path.relpath(file_path, path_to_model_folder)
        destination_path = os.path.join(temp_dir, relative_path)
        minio_client.fget_object(bucket_name, file_path, destination_path)
    converter = tf.lite.TFLiteConverter.from_saved_model(temp_dir)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS]
    converter._experimental_lower_tensor_list_ops = False
    tflite_model = converter.convert()

    data = data.astype(np.float32)
    num_samples = data.shape[0]
    predictions = []

    interpreter = tf.lite.Interpreter(model_content=tflite_model)
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    for i in tqdm(range(num_samples)):
        # Prepare input data for prediction 
        input_data = data[i].reshape(1, *input_details[0]['shape'][1:])
        
        # Set input tensor data
        interpreter.set_tensor(input_details[0]['index'], input_data)

        # Run the inference
        interpreter.invoke()

        # Get the output
        output_data = interpreter.get_tensor(output_details[0]['index'])
        
        # Store the prediction result
        predictions.append(output_data)

    predictions = np.vstack(predictions)
    predictions = unscale_data(predictions)
    predictions = clean_prediction(predictions)

    shutil.rmtree(temp_dir)

    num_hours = predictions.shape[0]
    start_date=time_now-timedelta(hours=num_hours)
    x=[start_date+timedelta(hours=i) for i in range(0,test_ex_per_hour)]
    prediction_df = pd.DataFrame()
    for index in segments_visualize:
        df = pd.DataFrame()
        df['Time'] = x
        df['Segment'] = segments[index]
        df['Predicted_Dwell_Time'] = predictions[:, index].tolist()
        prediction_df = pd.concat([prediction_df, df], ignore_index=True)

    return prediction_df
