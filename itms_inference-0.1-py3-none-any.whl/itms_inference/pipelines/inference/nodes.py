"""
This is a boilerplate pipeline 'inference'
generated using Kedro 0.18.9
"""
from minio import Minio
import time
import datetime 
import pytz
import h3
import pandas as pd
import calendar
import pickle
import numpy as np
from tqdm import tqdm
import dask.array as da
# import h3pandas
import os
import tensorflow as tf
from tensorflow.keras.layers import Input,Dense,Reshape,LSTM, Dropout
from tensorflow.keras.models import Model
from spektral.layers import GCNConv
from spektral.utils import gcn_filter
import folium
from shapely.geometry import Point
# import geopandas as gpd
import tempfile
import os
import shutil
from sqlalchemy import create_engine

def scale_data(data):
    max_speed = 500
    min_speed = -1
    data = (data - min_speed) / (max_speed - min_speed)
    return data

def unscale_data(data_scaled):
    max_time=500
    min_time=-1
    data_unscaled=(data_scaled*(max_time-min_time))+min_time
    return data_unscaled

def clean_prediction(prediction):
    for i in range(prediction.shape[0]):
        for j in range(prediction.shape[1]):
            if prediction[i,j]<0:
                prediction[i,j]=-1
    return prediction

def sequence_data_preparation(dwell_time_data):
    dwell_time_data = dwell_time_data.compute()
    dwell_time_data = dwell_time_data.to_numpy()
    seq_len = 4
    pre_len = 1
    dwell_time_data = scale_data(dwell_time_data)
    xtrue, ytrue = [], []
    for i in range(dwell_time_data.shape[1] - int(seq_len + pre_len - 1)):
        a = dwell_time_data[:, i: i + seq_len + pre_len]
        xtrue.append(a[:, :seq_len])
        ytrue.append(a[:, -1])
    # data = []
    # for i in range(dwell_time_data.shape[1] - int(seq_len + pre_len - 1)):
    #     a = dwell_time_data[:, i: i + seq_len + pre_len]
    #     data.append(a[:, :seq_len])
    # data = np.array(data)
    # data = np.reshape(dwell_time_data,(1,3498,4))
    xtrue = np.array(xtrue)
    ytrue = np.array(ytrue)
    return xtrue, ytrue

def inference(data, ytrue, adj_lap, segments, segments_visualize, time_now, segment_coords_dict):
    minio_client = Minio('minio-service.minio:9000',
                     access_key='miniouser',
                     secret_key='kjjAFEFvojiiy673nsn',
                     secure=False)
    bucket_name = 'itms-trip-delay'
    path_to_model_folder = '04_models/tgcn_model.h5'
    temp_dir = tempfile.mkdtemp(prefix='minio_temp_')
    objects = minio_client.list_objects(bucket_name, prefix=path_to_model_folder, recursive=True)
    for obj in objects:
        file_path = obj.object_name
        relative_path = os.path.relpath(file_path, path_to_model_folder)
        destination_path = os.path.join(temp_dir, relative_path)
        minio_client.fget_object(bucket_name, file_path, destination_path)
    converter = tf.lite.TFLiteConverter.from_saved_model(temp_dir)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS]
    converter._experimental_lower_tensor_list_ops = False
    tflite_model = converter.convert()

    data = data.astype(np.float32)

    interpreter = tf.lite.Interpreter(model_content=tflite_model)
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    interpreter.set_tensor(input_details[0]['index'], data)
    interpreter.invoke()
    predictions = interpreter.get_tensor(output_details[0]['index'])
    predictions = unscale_data(predictions)
    predictions = clean_prediction(predictions)

    shutil.rmtree(temp_dir)

    num_hours = predictions.shape[0]
    start_date=time_now
    x=[start_date-datetime.timedelta(hours=i) for i in range(0,num_hours)]
    prediction_df = pd.DataFrame()
    for index in segments_visualize:
        df = pd.DataFrame()
        df['Time'] = x
        df['Segment'] = segments[index]
        df['Actual_Dwell_Time'] = ytrue[:, index].tolist()
        df['Predicted_Dwell_Time'] = predictions[:, index].tolist()
        prediction_df = pd.concat([prediction_df, df], ignore_index=True)

    def trafficcategory(dtime):
        if dtime < 0:
            return 5
        elif dtime < 60:
            return 1
        elif dtime < 180:
            return 2
        elif dtime < 300:
            return 3
        else:
            return 5

    prediction_df['Traffic_Category'] = prediction_df['Predicted_Dwell_Time'].apply(trafficcategory)

    def seg_to_geojson(seg_id):
        return '{"type": "Polygon", "geometry": {"type": "Polygon", "coordinates": [' + str(segment_coords_dict[seg_id]) + ']}}'
    prediction_df['geojson'] = prediction_df['Segment'].apply(seg_to_geojson)
    prediction_df['geojson'] = prediction_df['geojson'].str.replace(r'\(', '[')
    prediction_df['geojson'] = prediction_df['geojson'].str.replace(r'\)', ']')

    db_url = 'postgresql://postgres:timescaledbpg@timescaledb-pgbouncer.dbspace:5432/postgresdb'
    engine = create_engine(db_url)
    table_name = 'itms_trip_delay_inference'
    prediction_df.to_sql(table_name, engine, if_exists='replace', index=False)
    return None
