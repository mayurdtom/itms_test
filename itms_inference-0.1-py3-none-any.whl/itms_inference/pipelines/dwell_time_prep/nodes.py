import pandas as pd
from typing import Dict, Tuple, List
import numpy as np
from tqdm import tqdm
from spektral.utils.convolution import gcn_filter
import dask.dataframe as dd
import dask
import dask.delayed
import dask.array as da
import pickle
import numpy as np
import math
import folium
import geopy.distance
import json
from shapely.geometry import LineString, Point
import matplotlib.pyplot as plt
from shapely.ops import shared_paths
import shapely
import pickle as pkl
import cvxpy as cvo
from datetime import date,time,datetime,timedelta
import h3
import rdp
import seaborn as sns
from haversine import haversine, Unit
import datetime
import pytz
from itertools import product
import psycopg2
from tensorflow.keras import Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input, Reshape
from tensorflow.keras.optimizers import Adam
from spektral.layers import GCNConv
from spektral.utils.convolution import gcn_filter
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tensorflow as tf
from datetime import datetime
from dask.dataframe import from_pandas
import random
import json
from bisect import bisect

IST = pytz.timezone('Asia/Kolkata')
time_now=datetime.now(IST)
time_now = time_now.replace(minute=0, second=0, microsecond=0)

def Euclidean(p1, p2):
    return (((p1[0]-p2[0])**2)+((p1[1]-p2[1])**2))**0.5

def geo_to_segment(latitude,longitude,h3_to_seg,new_segment_dict):
    h3_resolution=11 # edge length approx. 25 meters
    hid=h3.geo_to_h3(latitude,longitude,h3_resolution)
    notfound=True
    k=0
    hex_seg=hid
    while(notfound):
        ring=h3.k_ring(hid,k)
        for nh in ring:
            if nh in list(h3_to_seg.keys()):
                hex_seg=nh
                notfound=False
                break
        k+=1
        if k>3:
            return -1
    segment_ids=h3_to_seg[hex_seg]
    if len(segment_ids)==1:
        if segment_ids[0] in new_segment_dict:
            return segment_ids[0]
        else:
            return
    distances=[]
    for i in range(len(segment_ids)):
        sid=segment_ids[i]
        if sid in new_segment_dict:
            distances.append(min([(((c[0]-longitude)**2)+((c[1]-latitude)**2))**0.5 for c in new_segment_dict[sid]['coordinates']]))

    return segment_ids[distances.index(min(distances))]

def get_segment_dist(coords):
    dist=0
    for index in range(1,len(coords)):
        dist += haversine(coords[index-1], coords[index])
    return dist/2

def dwell_time_calc(h3_to_seg, new_segment_dict):
    # Time Slot
    def create_time_slot_upper_limits(start_time: time, end_time: time, slot_size: timedelta):
        placeholder_date = date(100, 1, 1)
        start_time = datetime.combine(placeholder_date, start_time)
        end_time = datetime.combine(placeholder_date, end_time)
                        
        time_slot_upper_limits = [start_time + slot_size]
        while time_slot_upper_limits[-1] < end_time:
            time_slot_upper_limits.append(min(time_slot_upper_limits[-1] + slot_size, end_time))
                                                
        return [val.time() for val in time_slot_upper_limits]
        
    now = time_now - timedelta(minutes = 300)
    if now < datetime.now(IST).replace(hour=8,minute=0, second=0, microsecond=0):
        now = time_now - timedelta(minutes = 1020)
    start_timestamp = now.strftime("'%Y-%m-%d %H:%M:%S'")
    end_timestamp = time_now.strftime("'%Y-%m-%d %H:%M:%S'")
    print(start_timestamp, end_timestamp)

    # Load data from postgres
    conn = psycopg2.connect(host="timescaledb-pgbouncer.dbspace", port="5432", database="postgresdb", user="postgres", password="timescaledbpg")
    cursor = conn.cursor()
    sql_query = """SELECT observationdatetime, license_plate, trip_id, route_id, trip_direction, "location.coordinates" FROM itms where observationdatetime >= {} AND observationDateTime < {} ORDER BY observationDateTime""".format(start_timestamp,end_timestamp)
    cursor.execute(sql_query)
    rows = cursor.fetchall()
    column_names = [desc[0] for desc in cursor.description]
    eta = pd.DataFrame(rows, columns=column_names)
    cursor.close()
    conn.close()

    eta['longitude']=eta['location.coordinates'].apply(lambda x:x.strip('()').split(',')[0])
    eta['latitude']=eta['location.coordinates'].apply(lambda x:x.strip('()').split(',')[-1])
    eta['longitude'] = eta['longitude'].astype(float)
    eta['latitude'] = eta['latitude'].astype(float)
    eta['observationdatetime'] = pd.to_datetime(eta['observationdatetime']).dt.tz_localize(None)

    START_TIME = time(0, 0, 0)
    END_TIME = time(23, 59, 59)
    SLOT_SIZE = timedelta(minutes=15)
    TIME_SLOT_UPPER_LIMITS = create_time_slot_upper_limits(START_TIME, END_TIME, SLOT_SIZE)
    FIRST_TIME_SLOT = 0
    LAST_TIME_SLOT = len(TIME_SLOT_UPPER_LIMITS) - 1

    def get_time_slot(time_slot_upper_limits, timestamp: pd.Timestamp):
        time_slot = bisect(time_slot_upper_limits, timestamp.time())
        if time_slot > LAST_TIME_SLOT:
            return LAST_TIME_SLOT
        return time_slot

    new_df_list = []
    no_segment_misses, less_message_misses, segment_dist_misses, zero_dwell_time_misses = 0, 0, 0, 0

    for trip in tqdm(eta["trip_id"].unique()):
        trip_df = eta[eta["trip_id"] == trip].reset_index(drop=True)
        license_plate = trip_df["license_plate"][0]
        route_id=trip_df['route_id'][0]
        trip_direction=trip_df['trip_direction'][0]
        trip_df = trip_df.loc[:, ["observationdatetime", "latitude", "longitude"]]
        trip_df = trip_df.sort_values("observationdatetime").reset_index(drop=True)

        # CALCULATE HASH VALUE FOR EACH LAT LONG PAIR FOR A PARTICULAR TRIP
        segment_col = []
        for i in range(len(trip_df)):
            segment_col.append(geo_to_segment(trip_df["latitude"][i], trip_df["longitude"][i], h3_to_seg, new_segment_dict))
        trip_df["segment"] = segment_col

        # FOR EVERY HASH VALUE FIND THE DWELL_TIME: THE DIFFERENCE OF FIRST AND LAST 'OBSERVATION_TIME'
        for segment in trip_df["segment"].unique():
            if segment==-1:
                no_segment_misses+=1
                continue
            segment_df = trip_df[trip_df["segment"] == segment].reset_index(drop=True)
            segment_df = segment_df.sort_values("observationdatetime").reset_index(drop=True)

            # IF THE DATA HAS LESS THEN 5 MESSAGES PER HEXAGON, THEN IGNORE THAT ROW
            if len(segment_df) < 2:
                less_message_misses+=1
                continue

            # FIND THE 'DWELL_TIME' BY TAKING THE DIFFERENFE OF LAST AND FIRST 'OBSERVATION_TIME'
            segment_start = segment_df.iloc[[0]]
            segment_end = segment_df.iloc[[-1]].reset_index(drop=True)

            # FINDING DISTANCE
            segment_dist = haversine([segment_start["latitude"][0], segment_start["longitude"][0]], [segment_end["latitude"][0], segment_end["longitude"][0]])

            # ELIMINATE DISTANCE BASED NOISE
            if segment_dist <= 1.5e-5:
                segment_dist_misses+=1
                continue

            # CALCULATE DWELL TIME
            segment_start_time = pd.to_datetime(segment_start["observationdatetime"].values[0])
            segment_end_time = pd.to_datetime(segment_end["observationdatetime"].values[0])
            travel_time = (segment_end_time - segment_start_time)/np.timedelta64(1,'s')
            if travel_time==0:
                continue
            travel_speed=segment_dist/travel_time

            dwell_time=new_segment_dict[segment]['length']/travel_speed

            # IGNORE THE ROWS WITH DWELL TIME EQUAL TO ZERO
            if dwell_time == 0.0:
                zero_dwell_time_misses+=1
                continue

            # GENERATE THE TIME SLOT USING OBSERVATION TIME
            #start_time_slot =  get_time_slot(TIME_SLOT_UPPER_LIMITS, pd.to_datetime(segment_start["observationDateTime"][0]))
            #end_time_slot =  get_time_slot(TIME_SLOT_UPPER_LIMITS, pd.to_datetime(segment_end["observationDateTime"][0]))
            start_time_slot = pd.to_datetime(segment_start["observationdatetime"][0]).hour
            end_time_slot = pd.to_datetime(segment_end["observationdatetime"][0]).hour

            # IF THERE ARE MULTIPLE TIME SLOTS, THEN GENERATE SEPERATE ROWS FOR EACH
            if start_time_slot != end_time_slot:
                if end_time_slot > start_time_slot:
                    for time_slot in range(start_time_slot, end_time_slot+1):
                        #time_slot = day_of_week + hour
                        new_df_list.append({"observed_time": segment_start_time,
                                            "route_id":route_id,
                                            "trip_id": trip,
                                            "trip_direction":trip_direction,
                                            "segment": segment,
                                            "segment_dist": segment_dist,
                                            "time_slot": time_slot,
                                            "dwell_speed": travel_speed,
                                            "dwell_time": dwell_time,
                                            "license_plate": license_plate
                                        })
                else:
                    for time_slot in range(start_time_slot, LAST_TIME_SLOT + 1):
                        new_df_list.append({"observed_time": segment_start_time,
                                            "route_id": route_id,
                                            "trip_id": trip,
                                            "trip_direction": trip_direction,
                                            "segment": segment,
                                            "segment_dist": segment_dist,
                                            "time_slot": time_slot,
                                            "dwell_speed": travel_speed,
                                            "dwell_time": dwell_time,
                                            "license_plate": license_plate})
                    for time_slot in range(0, end_time_slot + 1):
                        new_df_list.append({"observed_time": segment_start_time,
                                            "route_id": route_id,
                                            "trip_id": trip,
                                            "trip_direction": trip_direction,
                                            "segment": segment,
                                            "segment_dist": segment_dist,
                                            "time_slot": time_slot,
                                            "dwell_speed": travel_speed,
                                            "dwell_time": dwell_time,
                                            "license_plate": license_plate})
            else:
                time_slot = start_time_slot
                #time_slot = day_of_week + start_hour_slot
                new_df_list.append({"observed_time": segment_start_time,
                                    "route_id":route_id,
                                    "trip_id": trip,
                                    "trip_direction":trip_direction,
                                    "segment": segment,
                                    "segment_dist": segment_dist,
                                    "time_slot": time_slot,
                                    "dwell_speed": travel_speed,
                                    "dwell_time": dwell_time,
                                    "license_plate": license_plate
                                })

    new_df = pd.DataFrame(new_df_list)
    new_df = dd.from_pandas(new_df, npartitions=4)
    return new_df, time_now

def avg_dwell_time_calc(dwell_df, route_to_segments):
    dwell_df = dwell_df.compute()

    lengths = []
    for seg in new_segment_dict:
        lengths.append(new_segment_dict[seg]['length'])

    max_seg_length = max(lengths)
    avg_speed_bus = 10
    max_time_eta = max_seg_length*60*60/avg_speed_bus

    segment_dict_full = {val:new_segment_dict[val]['segment'] for val in new_segment_dict}

    def get_segment_dist(coords):
        dist=0
        for index in range(1,len(coords)):
            dist += haversine(coords[index-1], coords[index])
        return dist/2

    # new_segment_dict = {}
    # for segid,segment in segment_dict_full.items():
    #     new_segment_dict[segid]={
    #         "coordinates":list(segment.exterior.coords),
    #         "length": get_segment_dist(list(segment.exterior.coords)),
    #         "polygon": segment
    #     }

    segments = [segid for segid in new_segment_dict.keys()]
    time_slots = [time_slot for time_slot in dwell_df.time_slot.unique() if time_slot >= 8]

    def new_avg_dwelltime_calc(dwell_df):
        grouped_dwell_df = dwell_df.groupby(["segment","time_slot"])["dwell_time"].mean()
        tdf = grouped_dwell_df.reset_index()
        all_combinations = pd.DataFrame(list(product(segments, time_slots)), columns=['segment', 'time_slot'])
        avg_dwelltime_df = pd.merge(all_combinations, tdf, on=["segment", "time_slot"], how="left")
        avg_dwelltime_df = avg_dwelltime_df.rename(columns={"dwell_time": "avg_dwell_time"})
        return avg_dwelltime_df

    avg_dwelltime_df = new_avg_dwelltime_calc(dwell_df)

    def create_neighbours():
        neighbours = {}
        for segid in new_segment_dict:
            parent_routes = new_segment_dict[segid]["parent_routes"]

            neighbours[segid] = []
            for route_id in parent_routes:
                position = route_to_segments[route_id].index(segid)
                if position - 1 >= 0:
                    neighbours[segid].append((route_to_segments[route_id][position - 1], route_id))
                if position + 1 < len(route_to_segments[route_id]):
                    neighbours[segid].append((route_to_segments[route_id][position + 1], route_id))
        return neighbours

    neighbours = create_neighbours()

    def get_reasonable_val(avg_dwelltime_df, value, segid, time_slot):
        if not math.isnan(value):
            return value

        vals = []

        for nbr, _ in neighbours[segid]:
            val = avg_dwelltime_df[((avg_dwelltime_df["segment"] == nbr) & (avg_dwelltime_df["time_slot"] == time_slot))]["avg_dwell_time"]
            #print(nbr, time_slot)
            #print(val)
            if not val.isna().bool():
                vals.append(float(val))

        if vals == []:
            if time_slot - 1 >= time_slots[0]:
                val = avg_dwelltime_df[((avg_dwelltime_df["segment"] == segid) & (avg_dwelltime_df["time_slot"] == time_slot - 1))]["avg_dwell_time"]
                #print(val)
                if not val.isna().bool():
                    vals.append(float(val))
                for nbr, _ in neighbours[segid]:
                    val = avg_dwelltime_df[((avg_dwelltime_df["segment"] == nbr) & (avg_dwelltime_df["time_slot"] == time_slot - 1))]["avg_dwell_time"]
                    if not val.isna().bool():
                        vals.append(float(val))

            if time_slot + 1 <= time_slots[-1]:
                val = avg_dwelltime_df[((avg_dwelltime_df["segment"] == segid) & (avg_dwelltime_df["time_slot"] == time_slot + 1))]["avg_dwell_time"]
                if not val.isna().bool():
                    vals.append(float(val))
                for nbr, _ in neighbours[segid]:
                    val = avg_dwelltime_df[((avg_dwelltime_df["segment"] == nbr) & (avg_dwelltime_df["time_slot"] == time_slot + 1))]["avg_dwell_time"]
                    if not val.isna().bool():
                        vals.append(float(val))

        if vals:
            return sum(vals) / len(vals)
    
        return np.nan

    # global_avg_speed = np.median(dwell_df['dwell_speed']) * 3600

    def interpolate_df(avg_dwelltime_df):
        # Running this twice to avoid NaNs as much as possible.
        avg_dwelltime_df_copy = avg_dwelltime_df.copy()
        avg_dwelltime_df["avg_dwell_time"] = avg_dwelltime_df.apply(lambda row: get_reasonable_val(avg_dwelltime_df_copy, row["avg_dwell_time"], row["segment"], row["time_slot"]), axis=1)
        num_zeros_added = avg_dwelltime_df.isna().sum()["avg_dwell_time"]
        global_mean_val = avg_dwelltime_df["avg_dwell_time"].mean()
        mean_added_segs = avg_dwelltime_df[avg_dwelltime_df["avg_dwell_time"].isna()]["segment"].to_list()
        avg_dwelltime_df["avg_dwell_time"] = avg_dwelltime_df["avg_dwell_time"].apply(lambda val: global_mean_val if math.isnan(val) else val)
        
        return avg_dwelltime_df, num_zeros_added, mean_added_segs

    avg_dwelltime_df, num_zeros_added_train, mean_added_segs = interpolate_df(avg_dwelltime_df)

    # Reset index if needed
    avg_dwelltime_df.reset_index(drop=True, inplace=True)
    avg_dwelltime_df = dd.from_pandas(avg_dwelltime_df, npartitions=4)

    return avg_dwelltime_df, neighbours, max_time_eta