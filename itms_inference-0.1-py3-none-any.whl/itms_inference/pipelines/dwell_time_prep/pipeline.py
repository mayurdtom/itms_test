"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.18.4
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import dwell_time_calc, avg_dwell_time_calc
import warnings

warnings.filterwarnings("ignore")


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=dwell_time_calc,
                inputs=["h3_to_seg", "new_segment_dict"],
                outputs=["dwelltime_df", "time_now"],
                name="dwell_time_calc",
            ),
            node(
                func=avg_dwell_time_calc,
                inputs=["dwelltime_df","route_to_segments", "new_segment_dict"],
                outputs=["avg_dwelltime_df","neighbours", "max_time_eta"],
                name="avg_dwell_time_calc",
            ),
        ]
    )